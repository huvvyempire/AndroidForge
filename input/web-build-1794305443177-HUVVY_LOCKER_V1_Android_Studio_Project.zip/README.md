# HUVVY LOCKER V1

Native Android kiosk-style PIN lock app. This is an Android Studio project, not a Termux Python app and not a website.

- PIN: `12345`
- Five incorrect attempts trigger a 20-second cooldown.
- Immersive fullscreen UI with HUVVY purple branding.
- Device-owner provisioning enables Android Lock Task Mode.

## Build

1. Open this folder in Android Studio.
2. Let Gradle sync.
3. Build > Build APK(s).
4. Install the APK on your Android device.

## Important: real kiosk setup

For enforced Lock Task Mode, Android must recognize this app as the device owner. This is an advanced device-management setup and generally requires a freshly set-up / factory-reset device with no accounts, plus USB debugging and ADB from a computer.

After installing the APK, use:

```bash
adb shell dpm set-device-owner com.huvvy.locker/.HuvvyAdminReceiver
```

Then launch HUVVY LOCKER. If provisioning succeeds, it allowlists itself for Lock Task Mode and enters kiosk mode.

**Warning:** Device-owner provisioning changes device management and may require a factory reset to undo. Do not run it on a phone you cannot afford to reset. Test on a spare device first. To remove device-owner status, use Android's supported device-management removal procedure; do not rely on the app PIN as an administrator recovery method.

## Limitations

This does not prevent power-off, recovery mode, bootloader access, or every manufacturer-specific emergency/system path. Android may require setup-time provisioning and device-owner policies for full enforcement. This project is provided as a kiosk demonstration, not a guaranteed anti-theft or tamper-proof lock.
