package com.huvvy.locker

import android.app.admin.DeviceAdminReceiver

class HuvvyAdminReceiver : DeviceAdminReceiver()
