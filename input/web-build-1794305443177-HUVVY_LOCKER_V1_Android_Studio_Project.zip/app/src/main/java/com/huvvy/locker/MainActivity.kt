package com.huvvy.locker

import android.app.Activity
import android.app.admin.DevicePolicyManager
import android.content.ComponentName
import android.content.Context
import android.graphics.Color
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.widget.Button
import android.widget.GridLayout
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {
    private val pinCode = "12345"
    private val purple = Color.rgb(160, 90, 255)
    private val bg = Color.rgb(5, 5, 8)
    private var entered = ""
    private var failures = 0
    private var cooldownUntil = 0L
    private lateinit var pinView: TextView
    private lateinit var message: TextView
    private lateinit var dpm: DevicePolicyManager
    private lateinit var admin: ComponentName

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        window.decorView.systemUiVisibility = (
            View.SYSTEM_UI_FLAG_FULLSCREEN
                or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                or View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
                or View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                or View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                or View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
        )

        dpm = getSystemService(Context.DEVICE_POLICY_SERVICE) as DevicePolicyManager
        admin = ComponentName(this, HuvvyAdminReceiver::class.java)

        if (dpm.isDeviceOwnerApp(packageName)) {
            dpm.setLockTaskPackages(admin, arrayOf(packageName))
            if (android.os.Build.VERSION.SDK_INT >= 28) {
                dpm.setLockTaskFeatures(admin, DevicePolicyManager.LOCK_TASK_FEATURE_NONE)
            }
            startKioskIfNeeded()
        }

        buildScreen()
    }

    private fun startKioskIfNeeded() {
        try {
            if (dpm.isLockTaskPermitted(packageName)) startLockTask()
        } catch (_: Exception) { }
    }

    private fun buildScreen() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(28, 24, 28, 24)
            setBackgroundColor(bg)
        }

        val brand = TextView(this).apply {
            text = "HUVVY EMPIRE"
            textSize = 27f
            setTextColor(purple)
            gravity = Gravity.CENTER
            letterSpacing = 0.16f
        }
        root.addView(brand, matchWrap())

        val subtitle = TextView(this).apply {
            text = "HUVVY LOCKER V1"
            textSize = 14f
            setTextColor(Color.LTGRAY)
            gravity = Gravity.CENTER
            setPadding(0, 10, 0, 30)
        }
        root.addView(subtitle, matchWrap())

        pinView = TextView(this).apply {
            text = "•••••"
            textSize = 30f
            letterSpacing = 0.25f
            gravity = Gravity.CENTER
            setTextColor(Color.WHITE)
            setPadding(0, 12, 0, 18)
        }
        root.addView(pinView, matchWrap())

        val grid = GridLayout(this).apply {
            columnCount = 3
            rowCount = 4
            alignmentMode = GridLayout.ALIGN_BOUNDS
            useDefaultMargins = true
        }
        val keys = listOf("1","2","3","4","5","6","7","8","9","CLEAR","0","⌫")
        keys.forEach { key ->
            val button = Button(this).apply {
                text = key
                textSize = if (key.length > 1) 14f else 22f
                setTextColor(Color.WHITE)
                setBackgroundColor(Color.rgb(35, 25, 48))
                isAllCaps = false
                setOnClickListener { onKey(key) }
            }
            val params = GridLayout.LayoutParams().apply {
                width = 0
                height = dp(62)
                columnSpec = GridLayout.spec(GridLayout.UNDEFINED, 1f)
                setMargins(dp(5), dp(5), dp(5), dp(5))
            }
            grid.addView(button, params)
        }
        root.addView(grid, LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT
        ))

        message = TextView(this).apply {
            text = "ENTER YOUR PIN"
            textSize = 13f
            setTextColor(purple)
            gravity = Gravity.CENTER
            setPadding(0, 22, 0, 0)
        }
        root.addView(message, matchWrap())

        val footer = TextView(this).apply {
            text = "LOCAL DEVICE KIOSK"
            textSize = 10f
            setTextColor(Color.GRAY)
            gravity = Gravity.CENTER
            setPadding(0, 28, 0, 0)
        }
        root.addView(footer, matchWrap())
        setContentView(root)
    }

    private fun onKey(key: String) {
        if (System.currentTimeMillis() < cooldownUntil) {
            val seconds = ((cooldownUntil - System.currentTimeMillis()) / 1000L) + 1
            message.text = "WAIT ${seconds}s BEFORE TRYING AGAIN"
            return
        }
        when (key) {
            "CLEAR" -> entered = ""
            "⌫" -> if (entered.isNotEmpty()) entered = entered.dropLast(1)
            else -> if (entered.length < pinCode.length) entered += key
        }
        pinView.text = "●".repeat(entered.length).padEnd(pinCode.length, "○")
        if (entered.length == pinCode.length) checkPin()
    }

    private fun checkPin() {
        if (entered == pinCode) {
            failures = 0
            message.text = "ACCESS GRANTED"
            Toast.makeText(this, "HUVVY LOCKER unlocked", Toast.LENGTH_SHORT).show()
            try {
                if (dpm.isDeviceOwnerApp(packageName) && dpm.isLockTaskPermitted(packageName)) {
                    stopLockTask()
                }
            } catch (_: Exception) { }
            finish()
        } else {
            failures++
            entered = ""
            pinView.text = "○○○○○"
            if (failures >= 5) {
                failures = 0
                cooldownUntil = System.currentTimeMillis() + 20_000L
                message.text = "TOO MANY ATTEMPTS — WAIT 20 SECONDS"
            } else {
                message.text = "WRONG PIN — ${5 - failures} ATTEMPTS LEFT"
            }
        }
    }

    private fun matchWrap() = LinearLayout.LayoutParams(
        LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT
    )

    private fun dp(value: Int): Int =
        (value * resources.displayMetrics.density).toInt()

    override fun onBackPressed() {
        // Keep the lock screen visible while this activity is active.
        Toast.makeText(this, "Enter the PIN to unlock", Toast.LENGTH_SHORT).show()
    }

    override fun onResume() {
        super.onResume()
        if (::dpm.isInitialized && dpm.isDeviceOwnerApp(packageName)) startKioskIfNeeded()
    }
}
